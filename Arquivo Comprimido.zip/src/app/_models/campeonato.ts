﻿export class Campeonato {
    name: string;
    descr: string;
    id_sport: string;
}