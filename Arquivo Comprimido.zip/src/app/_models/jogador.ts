﻿export class Jogador {
    first_name: string;
    last_name: string;
    team_id: string;
    position_id: string;
    def_img: string;
}