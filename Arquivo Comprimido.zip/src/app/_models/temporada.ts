﻿export class Temporada {
    t_id: string;
    s_name: string;
    s_descr: string;
    published: string;
    s_win_point: string;
    s_lost_point: string;
    s_enbl_extra: string;
    s_extra_win: string;
    s_extra_lost: string;
    s_draw_point: string;
    s_groups: string;
    s_draw_away: string;
    s_lost_away: string;
    s_win_away: string;
}