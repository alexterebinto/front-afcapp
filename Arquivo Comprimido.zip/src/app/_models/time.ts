﻿export class Time {
    t_name: string;
    email: string;
    t_emblem: string;
    t_descr: string;
    t_email: string;
}