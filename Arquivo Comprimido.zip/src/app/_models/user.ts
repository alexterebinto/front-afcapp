﻿export class User {
    success: boolean;
    access_token: string;
}